/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ created: 12/28/2011
 */
 
#ifndef SIGNAL_MAP_H
#define SIGNAL_MAP_H

enum {
	INVALID_GAIN = 0xFFFF,
	DELTA = 1,
	EWMA_R_SHIFT_BIT = 4,	// right shift to scale down
	// scale gain for precision
	SCALE_L_SHIFT_BIT = 7,	//left shift to scale up
	SCALE = 128,	// 1 << SCALE_L_SHIFT_BIT
	
	// min SNR to ensure reliability 98% based on "$Dropbox/DNC/Students/Xiaohui/pdr_vs_sinr_curve.fig"
	RELIABLE_SNR_THRESHOLD = 10,
	
	// initial (interference+noise)
	INVALID_INTERFERENCE_NOISE = 0x7FFF,
	
	// initial ER interference threshold
	INVALID_INTERFERENCE_THRES = 0x7FFF,
	
	// differentiate data/ack reliability for now
	REFERENCE_DATA_PDR = 75,
	REFERENCE_ACK_PDR = 80,
};

// default signal map size; no larger than 127 due to ex_region_border_idx constraint
#ifndef SM_SIZE
#define SM_SIZE 120		// size is uint8_t
#endif

//signal map header
typedef nx_struct {
	nx_uint8_t power_level;
	// node's (interference+noise)
	nx_int16_t interference_noise;
	// number of entries in the footer
	nx_uint8_t footer_entry_cnts;
	// TODO
	nx_uint16_t seqno;
} sm_header_t;

//signal map footer containing neighbor and inbound gain, used to compute outbound gain
typedef nx_struct {
	nx_am_addr_t nb;
	//power gain to a neighbor
	nx_uint16_t inbound_gain;
} sm_footer_t;

//signal map entry
typedef struct {
	am_addr_t nb;
	bool valid;
	// useful when deciding tx power level for RTS/CTS
	int16_t interference_noise;
	// scaled
	// to compute ER
	uint16_t inbound_gain;
	// to compute RTS/CTS tx power & determine if I'm in the ER of the neighbor
	uint16_t outbound_gain;
	// ER
	int16_t tx_interference_threshold;
	int16_t rx_interference_threshold;	
/* boundary of the current exclusion region for the link to this neighbor (inbound), 
 * i.e., outmost node index within the ER in SM
 * ER is the set of neighbors from [0 .. ex_region_border_idx] in SM
 * -1 means empty ER
 */
	// when I transmit to the neighbor
	int8_t tx_er_border_idx;
	// when I receive from the neighbor
	int8_t rx_er_border_idx;
} sm_entry_t;

#endif
