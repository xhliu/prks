/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 04/05/2012 08:56:00 PM 
 */

#ifndef TEST_IMAC_H
#define TEST_IMAC_H

#include "../iMAC/beaconing/IMACBeacon.h"

// enable signal map
#define SIGNAL_MAP

typedef nx_struct radio_count_msg {
	nx_uint16_t src;
	nx_uint16_t seqno;
} radio_count_msg_t;

enum {
	AM_IMAC_LE = 6,
	AM_IMAC_SM = 7,
	
	TX_FAIL_FLAG = 0,
	TX_FLAG = 1,
	TX_DONE_FLAG = 2,
	RX_FLAG = 3,
	
	DBG_FLAG = 255,

	INITIAL_SM_TIME = BEACON_PERIOD_SHORT * BEACON_PERIOD_SHORT_CNT,

	PERIOD = 100,	//500
	INITIAL_LE_PKT_CNT = 200,
	MAX_PKT_CNT = 1000,
};

#endif
