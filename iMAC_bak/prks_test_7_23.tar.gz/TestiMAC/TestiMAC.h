/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 04/05/2012 08:56:00 PM 
 */

#ifndef TEST_IMAC_H
#define TEST_IMAC_H

#include "IMAC.h"


// basic CSMA
//#define DEFAULT_MAC
//#define RTSCTS
//#define CMAC

#if defined(CMAC)
#include "IMACBeacon.h"
#endif

#if defined(DEFAULT_MAC) || defined(RTSCTS) || defined(CMAC)
	#warning change Makefile !!!
#else
	// PRKS specific
	
	// disable SPI resource arbitration
	#define DUMMY_SPI

	//#warning disable fix packet-level time sync: sender-side
	#define TIMESYNC_FIX

	#define TEST_FTSP
#endif
// use FastCC2420TransceiverC to replace ActiveMessage; no iMAC neither
//#define RAW_FAST_MAC


// choose controller
//#define MIN_VAR_CONTROLLER

// enable tx ER
//#define TX_ER

// ensure slot integrity, see IMACForwarderP for more info
//#define SLOT_INTEGRITY

// enable signal map
#define SIGNAL_MAP

// only works assuming the smallest id node does not change, which holds for static testbeds
#define FTSP_FIX
//#define FAST_SMCLK

enum {
// fit in one pkt after format change
#if defined(DEFAULT_MAC)
#warning
	// not using 110 to be safe
	PLACE_HOLDER_LEN = 106,
#elif defined(RTSCTS)
	// maxPayloadLength 99, to accomodate linkestimator footer
	PLACE_HOLDER_LEN = 91,
#elif defined(CMAC)
	// 4 bytes less than RTS-CTS
	PLACE_HOLDER_LEN = 86,
#else
	PLACE_HOLDER_LEN = 22,	// 86
#endif
	TX_FAIL_FLAG = 0,
	TX_SUCCESS_FLAG = 1,
	TX_DONE_FLAG = 2,
	RX_FLAG = 3,
	TX_DONE_FAIL_FLAG = 4,
	
	DBG_FLAG = 255,
	DBG_LOSS_FLAG = 0,
	DBG_TX_FLAG = DBG_LOSS_FLAG + 1,
	DBG_RX_FLAG = DBG_TX_FLAG + 1,
	DBG_BACKOFF_FLAG = DBG_RX_FLAG + 1,
	DBG_ER_FLAG = DBG_BACKOFF_FLAG + 1,
	DBG_SM_FLAG = DBG_ER_FLAG + 1,				//5
	DBG_TX_FAIL_FLAG = DBG_SM_FLAG + 1,
	DBG_TIMEOUT_FLAG = DBG_TX_FAIL_FLAG + 1,
	DBG_BI_ER_FLAG = DBG_TIMEOUT_FLAG + 1,
	DBG_EXEC_TIME_FLAG = DBG_BI_ER_FLAG + 1,
	DBG_DELAY_FLAG = DBG_EXEC_TIME_FLAG + 1,	//10
	DBG_CANCEL_FLAG = DBG_DELAY_FLAG + 1,
	DBG_CONTROLLER_FLAG = DBG_CANCEL_FLAG + 1,
	DBG_COUNTER_NAV_FLAG = DBG_CONTROLLER_FLAG + 1,
	DBG_CALC_FLAG = DBG_COUNTER_NAV_FLAG + 1,
	DBG_HEARTBEAT_FLAG = DBG_CALC_FLAG + 1,		// 15
	DBG_FTSP_FLAG = DBG_HEARTBEAT_FLAG + 1,
	DBG_TDMA_FLAG = DBG_FTSP_FLAG + 1,
	DBG_SPI_FLAG = DBG_TDMA_FLAG + 1,
	DBG_DRIVER_FLAG = DBG_SPI_FLAG + 1,
	DBG_ERR_FLAG = DBG_DRIVER_FLAG + 1,			//20

	/**
		initial stage:
		[0 .. INITIAL_ER_TIME] jump start signal map
		[INITIAL_ER_TIME .. INITIAL_FTSP_TIME] exchange link ERs
		[0 .. INITIAL_FTSP_TIME] jump start ftsp
	 */
	//SM_BEACON_CNT = 1000UL, // 2000 seems insufficient
	// when to initialize ER w/ tx range afte SM is valid; SM_BEACON_PERIOD is 50 ms
	//INITIAL_ER_TIME = (uint32_t)SM_BEACON_PERIOD_MILLI * SM_BEACON_CNT,
	//FTSP_BEACON_CNT = (SM_BEACON_CNT << 1),
	// when to start data forwarding after ftsp converges
	//INITIAL_FTSP_TIME = (uint32_t)SM_BEACON_PERIOD_MILLI * FTSP_BEACON_CNT,
#if defined(DEFAULT_MAC) || defined(RTSCTS)
	START_DATA_TIME = 30000,
#elif defined(CMAC)
	#warning
	// refer to IMACBeacon.h
	START_DATA_TIME = (uint32_t)BEACON_PERIOD_SHORT * BEACON_PERIOD_SHORT_CNT + 300000U,
#else
	START_DATA_TIME = INITIAL_ER_TIME,
#endif
//	#warning period 1000
	PERIOD_MILLI = 20,
	MAX_PKT_CNT = 45000U,
	
	TYPE_SYNC = 12,
};

typedef nx_struct radio_count_msg {
	nx_uint16_t src;
	nx_uint16_t seqno;
	// to make pkt len equal for fair comparison
	nx_uint8_t place_holder[PLACE_HOLDER_LEN];
} radio_count_msg_t;


// sync
//enum {
//	// sync	
//	AM_TYPE_SYNC = 12,
//	BUFFER_TIME = 2000,
//	CONVERGE_TIME = 300000U,
//};

typedef nx_struct {
	nx_uint16_t seqno;
	nx_uint32_t globalTime;
} sync_header_t;

#endif
