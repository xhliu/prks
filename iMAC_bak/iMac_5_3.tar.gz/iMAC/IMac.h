#ifndef IMAC_H
#define IMAC_H

enum {
	// EWMA, w/ a denominator of 10
	ALPHA = 9,
	SCALE_L_SHIFT_BIT = 7,
};
#endif
