/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 06/27/2012 
 */
 
#ifndef IMAC_FORWARDER_H
#define IMAC_FORWARDER_H

enum {
	// duration of a slot 10 ms in jiffies
	SLOT_LEN = 320,
	// 870 / 1024 * 32 (channel switch) + 10 (sync err)
	BACKOFF_WINDOW = 37,
	
	// control channel
	CC2420_CONTROL_CHANNEL = 19,
};

// TODO: redundant header lest sth needs to be piggybacked later
typedef nx_struct {
	nx_uint8_t place_holder;
} imac_header_t;


#endif
