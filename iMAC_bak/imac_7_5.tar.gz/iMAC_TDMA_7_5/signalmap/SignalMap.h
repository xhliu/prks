/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * @ created: 12/28/2011
 */
 
#ifndef SIGNAL_MAP_H
#define SIGNAL_MAP_H

#include "IMac.h"

enum {
	INVALID_GAIN = 0x7FFF,
	OFFSET = 1,
	EWMA_R_SHIFT_BIT = 4,	// right shift to scale down
	
	// initial (interference+noise)
	INVALID_DBM = 0x7FFF,
	// min signed 16 bits
	MIN_DBM = 0x8000,
	
	// default signal map size
	// size is int16_t to accommodate network consisting of more than 256 nodes
	SM_SIZE = 60,		// accommodate some illegitimate nodes of corrupted node id
	LINK_TABLE_SIZE = 100,
};

// ER and PDR of the link btw. me and nb
typedef nx_struct {
	// ER
	// am I the sender?
	nx_bool is_sender;
	nx_am_addr_t nb;
	nx_int16_t tx_interference_threshold;
	nx_int16_t rx_interference_threshold;
	
	// pdr
	nx_uint8_t inquality;
	nx_uint8_t inquality_version;
} link_er_pdr_t;

//signal map header
typedef nx_struct {
	nx_uint8_t power_level;
	// number of entries in the footer
	nx_uint8_t footer_entry_cnts;
	// TODO: remove after debug
	nx_uint16_t seqno;
	// ER of link from/to a neighbor to/from me
	link_er_pdr_t link_er_pdr[LINK_ER_SIZE];
} sm_header_t;

//signal map footer containing neighbor and inbound gain, used to compute outbound gain
typedef nx_struct {
	nx_am_addr_t nb;
	// my signal map
	nx_int16_t inbound_gain;
	nx_int16_t outbound_gain;	
} sm_footer_t;

// represent \delta_Is
// 0 is represented as {0, 0}
typedef struct {
	// can only be 1, 0 or -1
	int8_t sign;
	// absolute value in dBm; thus can be negative
	int16_t abs;
} dbm_t;

//signal map entry
typedef struct {
	am_addr_t nb;
	bool valid;
	
	// scaled
	// to compute ER
	int16_t inbound_gain;
	// to compute RTS/CTS tx power & determine if I'm in the ER of the neighbor
	int16_t outbound_gain;
	
	// ER
	// TODO: store as a seperate table if memory is ever a concern since only neighbors talking to me 
	// need to be maintained, whose # if much less than SM_SIZE
	int16_t tx_interference_threshold;
	int16_t rx_interference_threshold;	
/* boundary of the current exclusion region for the link to this neighbor (inbound), 
 * i.e., outmost node index within the ER in SM
 * ER is the set of neighbors from [0 .. ex_region_border_idx] in SM
 * -1 means empty ER
 */
	// when I transmit DATA to the neighbor
	int16_t tx_er_border_idx;
	// when I receive DATA from the neighbor
	int16_t rx_er_border_idx;
	
	// min variance controller related info
	// capital I means in capsulation
	// mean noise+interference for a link during interval (t, t+1] so far
	dbm_t tx_I;
	dbm_t rx_I;
	// # of samples in interval (t, t+1] so far
	//int16_t tx_i_cnt;
	//int16_t rx_i_cnt;
	// I(t - 1): mean interference+noise for a link during interval (t - 1, t]
	dbm_t tx_prev_I;
	dbm_t rx_prev_I;
	//int16_t tx_prev_i;
	//int16_t rx_prev_i;
	// \Delta I_d(t): previous desired NI change; scaled
	dbm_t tx_delta_I_d;
	dbm_t rx_delta_I_d;
	// \bar(\Delta I_u(t)) mean delta unknown NI change; scaled
	dbm_t tx_mean_delta_I_u;
	dbm_t rx_mean_delta_I_u;
} sm_entry_t;

typedef struct {
	am_addr_t nb;
	int16_t inbound_gain;
	int16_t outbound_gain;
} signal_map_entry_t;

// neighbor's signal map, from/to whom there is a link
typedef struct {
	am_addr_t nb;
	bool valid;
	signal_map_entry_t signal_map[SM_SIZE];
} nb_signal_map_entry_t;

// link table
typedef struct {
	am_addr_t sender;
	am_addr_t receiver;
	bool valid;
	int16_t tx_interference_threshold;
	int16_t rx_interference_threshold;
} link_table_entry_t;

#endif
