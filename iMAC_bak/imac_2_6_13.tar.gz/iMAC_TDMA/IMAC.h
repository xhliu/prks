#ifndef IMAC_H
#define IMAC_H

enum {
	AM_IMAC_LE = 6,
	AM_IMAC_SM = 7,
	
	// EWMA, w/ a denominator of 10
	ALPHA = 9,
	// 128
	SCALE_L_SHIFT_BIT = 7,
	
	// PDR requirement; differentiate data/ack reliability for now
	REFERENCE_DATA_PDR = 75,
	REFERENCE_ACK_PDR = 80,

	// corresponds to power level 3
	CC2420_DEF_RFPOWER_DBM = -25,
	CC2420_DEF_RFPOWER_DBM_SCALED = CC2420_DEF_RFPOWER_DBM << SCALE_L_SHIFT_BIT,
	// power level
	CONTROL_POWER_LEVEL = 31,
	
	// size is int16_t to accommodate network consisting of more than 256 nodes
	SM_SIZE = 64,
	SM_SIZE_MODULAR = 0x3F,	// x % SM_SIZE == x & SM_SIZE_MODULAR

	// can be less than max # of active links in the ntw; keep LINK_ER_TABLE_SIZE of them
	MAX_ACTIVE_LINK_SIZE = SM_SIZE,	//100
	// max # of links a node can be incident w/
	MAX_INCIDENT_LINK_SIZE = 4, // 5,
	NB_SIGNAL_MAP_SIZE = MAX_INCIDENT_LINK_SIZE,
	LOCAL_LINK_ER_TABLE_SIZE = MAX_INCIDENT_LINK_SIZE,
	NEIGHBOR_TABLE_SIZE = MAX_INCIDENT_LINK_SIZE,
	LINK_ER_TABLE_SIZE = MAX_ACTIVE_LINK_SIZE,
	NB_ER_CI_TABLE_SIZE = MAX_INCIDENT_LINK_SIZE,
	
	// invalid global time
	INVALID_TIME = 0xFFFFFFFF,
	INVALID_ADDR = 0xFFFF,
//#warning fake control channel
	// control channel; see Guoliang RTSS09 Section 3B
	CC2420_CONTROL_CHANNEL = 19,
	
	// period to send signal map beacons at the beginning
	// cannot exceed 64 ms bcoz IMACForwarderP$SlotTime is uint16_t
	SM_BEACON_PERIOD_MILLI = 50UL,
};

#endif
