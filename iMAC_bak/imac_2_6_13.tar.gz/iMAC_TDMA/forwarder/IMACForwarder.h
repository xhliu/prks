/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 06/27/2012 
 */
 
#ifndef IMAC_FORWARDER_H
#define IMAC_FORWARDER_H

enum {
	//#warning all duration in uis
	SLOT_LEN = 24 * 1024, //(16384UL << 1),
//	SLOT_LEN_SHIFT = 15,	// 2 ^ 14 = 16384
//	SLOT_HEX_MODULAR = 0x00007FFF, // x % SLOT_LEN == x & SLOT_HEX_MODULAR
	
	// contention window size
	MIN_CW = 2000, //2000,
	// CW = 2048
	CW_HEX_MODULAR = 0x7FF,	// x % CW == x & CW_HEX_MODULAR
	
	// max pairwise global time difference
//	SYNC_ERROR = 4000,
	// max firing latency due to IRS processing of alarm interrupt, excluding other interrupts
//	FIRE_LATENCY = 1000,
//	HOLD_TIME = SYNC_ERROR + FIRE_LATENCY,
//	SYNC_TIME = 1000, //4000,
	
//#warning based on diff btw. max DATA and max CONTROL delay
	// actual backoff window is BACKOFF_WINDOW + processing jitter from of send, including TXFIFO loading; using processing jitter and sync error as implicit backoff
	// probability of collision = 1%
//	BACKOFF_WINDOW = 10,	//640,
	// tx duration in ctrl channel, including ctrl & ftsp packets (see "async_delay_breakdown.fig")
	//CTRL_TX_DURATION = 4000,
	// be conservative, see "channel_switch_delay.fig"
//	CHANNEL_SWITCH_DELAY = 180,
	
	// tx ftsp beacon instead of ctrl pkt 1 out of CTRL_SLOT_FTSP_CHANCE when ctrl channel available
	INIT_CTRL_SLOT_FTSP_CHANCE_MASK = 0x1,
	// tunable
	CTRL_SLOT_FTSP_CHANCE_MASK = 0x1,
	
	// prioritize ctrl/ftsp pkt if consecutive CCA loss exceeding MAX_CCA_FAIL_CNT
	// MAX_CCA_FAIL_CNT = 10,
	// 1 out of 22,000; 22.2 s drifts 1 ms; be conservative and compensate drift every 2 s;
	// not exactly 65536 to avoid perfect alignment and the resulting 0 firing alarm
//	SYNC_PERIOD = 65535UL,
};

// TODO: redundant header lest sth needs to be piggybacked later
typedef nx_struct {
	nx_uint8_t seq;
} imac_header_t;


#endif
