#ifndef FAST_CC2420_TRANSCEIVER_H
#define FAST_CC2420_TRANSCEIVER_H

// additional software CRC
typedef nx_uint16_t fast_footer_t;

#endif
