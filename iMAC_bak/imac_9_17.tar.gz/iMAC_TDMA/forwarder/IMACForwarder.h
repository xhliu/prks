/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 06/27/2012 
 */
 
#ifndef IMAC_FORWARDER_H
#define IMAC_FORWARDER_H

enum {
//#warning long slot for debug
	// duration of a slot in jiffies:
	SLOT_LEN = 1024,	// 1024		99 percentile
	SLOT_LEN_SHIFT = 10,	// 2 ^ 10 = 1024
	SLOT_HEX_MODULAR = 0x000003FF,	//0x000003FF 	x % SLOT_LEN == x & SLOT_HEX_MODULAR
//#warning "reduce ctrl pkt frequency to (1 / DECISION_CNT) is this still necessary after timesync fix: even 1 works"
	//DECISION_CNT = 1, // 32

#warning based on diff btw. max DATA and max CONTROL delay 
	BACKOFF_WINDOW = 100, // probability of collision = 1%
	RX_DURATION = 500,	// 500: 99 percentile tx duration
	
	// 1 out of 22,000; 22.2 s drifts 1 ms; be conservative and compensate drift every 2 s;
	// not exactly 65536 to avoid perfect alignment and the resulting 0 firing alarm
	SYNC_PERIOD = 65535UL,
	
	// invalid global time
	INVALID_TIME = 0,
	
	// do not send any DATA/CONTROL to let ftsp converge first
//	INITIAL_FTSP_TIME = 180000UL * 32,
};

// TODO: redundant header lest sth needs to be piggybacked later
typedef nx_struct {
	nx_uint8_t seq;
} imac_header_t;


#endif
