/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 06/27/2012 
 */
 
#ifndef IMAC_FORWARDER_H
#define IMAC_FORWARDER_H

enum {
//#warning restore slot len of 105 ms for debug
	// duration of a slot in jiffies: 35
	SLOT_LEN = 1120,	// 1600 + 100 works
//#warning 	 higher ctrl pkt frequency to (1 / DECISION_CNT)
	DECISION_CNT = 30, //150,	//30,

	// period to send signal map beacons at the beginning
	// 5 s = 32 * 1024 * 5 jiffies
//#warning shorten to 1 s for debug
	SM_BEACON_PERIOD = 163840UL, //32768UL,
	// 2 ms
	BACKOFF_WINDOW = 64,
	
	// 1 out of 22,000; 22.2 s drifts 1 ms; be conservative and compensate drift every 2 s; 
	SYNC_PERIOD = 65536UL,
	
	// do not send any DATA/CONTROL to let ftsp converge first
//	INITIAL_FTSP_TIME = 180000UL * 32,
};

// TODO: redundant header lest sth needs to be piggybacked later
typedef nx_struct {
	nx_uint8_t seq;
} imac_header_t;


#endif
