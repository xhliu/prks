#ifndef IMAC_H
#define IMAC_H

enum {
	AM_IMAC_LE = 6,
	AM_IMAC_SM = 7,
	
	// EWMA, w/ a denominator of 10
	ALPHA = 9,
	SCALE_L_SHIFT_BIT = 7,
	
	// PDR requirement; differentiate data/ack reliability for now
	REFERENCE_DATA_PDR = 75,
	REFERENCE_ACK_PDR = 80,
	
	// corresponds to power level 3
	CC2420_DEF_RFPOWER_DBM = -25,
	CC2420_DEF_RFPOWER_DBM_SCALED = CC2420_DEF_RFPOWER_DBM << SCALE_L_SHIFT_BIT,
	// power level
	CONTROL_POWER_LEVEL = 31,

	// max # of active links in the ntw
	MAX_ACTIVE_LINK_SIZE = 100,
	// max # of links a node can be incident w/
	MAX_INCIDENT_LINK_SIZE = 5,
	// default signal map size
	// size is int16_t to accommodate network consisting of more than 256 nodes
	SM_SIZE = 120,		// accommodate some illegitimate nodes of corrupted node id
	NB_SIGNAL_MAP_SIZE = MAX_INCIDENT_LINK_SIZE,
	LINK_ER_TABLE_SIZE = MAX_INCIDENT_LINK_SIZE,
	NEIGHBOR_TABLE_SIZE = MAX_INCIDENT_LINK_SIZE,
	NB_LINK_ER_TABLE_SIZE = MAX_ACTIVE_LINK_SIZE,
	
	INVALID_ADDR = AM_BROADCAST_ADDR,

	// control channel
	CC2420_CONTROL_CHANNEL = 19,
};

#endif
