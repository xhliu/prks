/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 04/05/2012 08:56:00 PM 
 */

#ifndef TEST_IMAC_H
#define TEST_IMAC_H

#include "../iMAC/beaconing/IMACBeacon.h"

// bypass iMAC and use AMSenderC directly
//#define DISABLE_IMAC

// enable signal map
#define SIGNAL_MAP

// fix sync error; needed for global sync to measure w/o concurrency
#define RX_TIMESTAMP

typedef nx_struct radio_count_msg {
	nx_uint16_t src;
	nx_uint16_t seqno;
#ifdef DISABLE_IMAC
	// to make pkt len the same as iMAC for fair comparison
	nx_uint8_t place_holder[12];
#endif
} radio_count_msg_t;

enum {
	AM_IMAC_LE = 6,
	AM_IMAC_SM = 7,
	
	TX_FAIL_FLAG = 0,
	TX_FLAG = 1,
	TX_DONE_FLAG = 2,
	RX_FLAG = 3,
	
	DBG_FLAG = 255,
	DBG_LOSS_FLAG = 0,
	DBG_TX_FLAG = DBG_LOSS_FLAG + 1,
	DBG_RX_FLAG = DBG_TX_FLAG + 1,
	DBG_BACKOFF_FLAG = DBG_RX_FLAG + 1,

	INITIAL_SM_TIME = BEACON_PERIOD_SHORT * BEACON_PERIOD_SHORT_CNT,

	PERIOD = 200,	//40,
	INITIAL_LE_PKT_CNT = 2000,
	MAX_PKT_CNT = 10000,	//500,
};

// sync
enum {
	// sync	
	AM_TYPE_SYNC = 12,
	BUFFER_TIME = 2000,
	CONVERGE_TIME = 300000U,
};

typedef nx_struct {
	nx_uint16_t seqno;
	nx_uint32_t globalTime;
} sync_header_t;
#endif
