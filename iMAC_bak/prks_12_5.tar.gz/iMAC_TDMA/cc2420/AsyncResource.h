#ifndef ASYNC_RESOURCE_H
#define ASYNC_RESOURCE_H

enum {
	TX_CLIENT = 0,
	RX_CLIENT = 1,
};
#endif
