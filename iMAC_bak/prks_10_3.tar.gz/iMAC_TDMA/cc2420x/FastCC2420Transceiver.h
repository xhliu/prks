#ifndef FAST_CC2420_TRANSCEIVER_H
#define FAST_CC2420_TRANSCEIVER_H

enum {
	RSSI_OFFSET = 45,
};
//typedef nx_struct ieee154_simple_header_t
//{
//	nxle_uint16_t fcf;
//	nxle_uint8_t dsn;
//	nxle_uint16_t destpan;
//	nxle_uint16_t dest;
//	nxle_uint16_t src;
//} ieee154_simple_header_t;

//typedef nx_struct network_header_t
//{
//	nxle_uint8_t network;
//} network_header_t;

//typedef nx_struct activemessage_header_t
//{
//	nx_am_id_t type;
//} activemessage_header_t;

//typedef struct timestamp_metadata_t
//{
//	uint32_t timestamp;
//} timestamp_metadata_t;

//typedef struct flags_metadata_t
//{
//	// TODO: make sure that we have no more than 8 flags
//	uint8_t flags;
//} flags_metadata_t;

#endif
