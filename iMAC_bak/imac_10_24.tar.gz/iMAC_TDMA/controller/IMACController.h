/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 04/05/2012 08:56:00 PM 
 */
#ifndef IMAC_CONTROLLER_H
#define IMAC_CONTROLLER_H

#include "IMAC.h"
#include "SignalMap.h"

enum {
	// scaled by 100
	DELTA_Y = 0,
	// 0.15: scaled by 100
	E0 = 15,
	
	// empty ER
	EMPTY_ER_IDX = -1,
	
	// max # of ER items to place in a packet
	// save as much space as possible to accommodate signal map entries initially
	INIT_MAX_ITEM_CNT = 0,
#warning const to be changed after d_0 finished
	MAX_ITEM_CNT = 2,
	
	// initial prio of other links' ER items: sort of "THL"
	NON_LOCAL_INIT_PRIO = 1,

    //sqrt(qtl / (1 - qtl))
    CHEBYSHEV_SCALAR = 3,   //qtl 0.9
    
    BITSHIFT_3 = 3,
};

typedef nx_struct {
	nx_uint8_t local_link_pdr_cnt;
	nx_uint8_t link_er_cnt;
#warning add seq for debug
	nx_uint16_t seqno;
} imac_control_header_t;

// footer includes first PDR and then ER
// local link's PDR
typedef nx_struct {
	nx_am_addr_t nb;
	// pdr piggybacked in ctrl pkt in case DATA receiver does not act as sender
	nx_uint8_t inquality;
	nx_uint8_t inquality_version;
	// d_0 quantile; piggyback from receiver to sender	
	nx_uint32_t d0_self_qtl;
	nx_uint32_t d0_other_qtl;
} local_link_pdr_footer_t;


typedef nx_struct {
	nx_am_addr_t nb;
#ifdef TX_ER
	// CI for ER when link btw. me & nb is selected
	nx_uint32_t tx_effective_time;
#endif
	nx_uint32_t rx_effective_time;
} nb_effective_time_t;

// ER item
typedef nx_struct {
	nx_am_addr_t sender;
	nx_am_addr_t receiver;
#ifdef TX_ER
	nx_int16_t tx_interference_threshold;
	nx_uint8_t tx_version;
	nx_uint32_t tx_generation_time;
	nx_uint32_t tx_arrival_time;
#endif
	nx_int16_t rx_interference_threshold;
	nx_uint8_t rx_version;
	nx_uint32_t rx_generation_time;
	nx_uint32_t rx_arrival_time;
	
	// TODO: variable length to save space
	// for link consistency, i.e., to min CIs at sender and receiver of a link
	nb_effective_time_t nb_effective_time[LOCAL_LINK_ER_TABLE_SIZE];
} link_er_footer_t;

typedef struct {
	// ER passing this neighbor, either directly (category 1) or indirectly (category 0)
	//am_addr_t nb;
	// used to sample d_0 yet, i.e., the ER has not passed this neighbor to me yet
	//bool sampled;
#ifdef TX_ER
	// current tx ER
	int16_t cur_tx_interference_threshold;
	// critical instant: time to replace cur_tx_interference_threshold w/ the latest ER 
	// if link btw. nb & me wins among all local links, i.e., win_link_idx in IMACForwarderPUtil$contend()
	uint32_t tx_effective_time;
#endif
	int16_t cur_rx_interference_threshold;
	uint32_t rx_effective_time;
} nb_er_ci_entry_t;

// link table entry <link, ER, >
typedef struct {
	am_addr_t sender;
	am_addr_t receiver;
	
	bool valid;
	uint8_t prio;
	// index within active links; used to compute priority
	uint8_t link_idx;
#ifdef TX_ER	
	//// latest tx ER
	int16_t tx_interference_threshold;
	uint8_t tx_version;
	// d_0 related; all time is in global time
	// time ER is generated; no updated along relay
	uint32_t tx_generation_time;
	// time ER first arrives, either locally generated or overheard; updated along relay
	uint32_t tx_arrival_time;
#endif	
	int16_t rx_interference_threshold;
	uint8_t rx_version;
	uint32_t rx_generation_time;
	uint32_t rx_arrival_time;

	
	//// neighbor ER and critical instant table
	// ER effective time is per link
	// neighbor order is the same as in localLinkERTable to save processing of table lookup
	// TODO: # of incident links cannot exceed 8
	//// bitmaps: i-th bit indicates whether i-th incident link
	// contends w/ this link? also depends on which incident link wins locally??
	uint8_t contend_flags;
	// is used to sample d_0
	uint8_t sample_flags;
#ifdef TX_ER
	// 's current tx ER is replaced by latest ER
	uint8_t tx_update_flags;
#endif
	// 's current rx ER is replaced by latest ER
	uint8_t rx_update_flags;
	// local v.s. non-local links
	// for local, only entry w/ local_idx is valid since it can only comes from the other end
	// for non-local: all entries corresponding to a neighbor is valid since it can come from any of them
	nb_er_ci_entry_t nbERCITable[LOCAL_LINK_ER_TABLE_SIZE];
} link_er_table_entry_t;

// local link ER table entry
// store as a seperate table from signal map if memory is ever a concern since only neighbors talking to me need to be maintained, whose # is much less than SM_SIZE
// TODO: further reduce since a link is seldomly bidirectional, store seperately if this ever occurs, differentiated by is_sender
typedef struct {
	am_addr_t nb;

	bool valid;
	bool is_sender;
	// index within active links; used to compute priority
	uint8_t link_idx;

#ifdef TX_ER
	int16_t tx_interference_threshold;
	uint8_t tx_version;
	// when I transmit DATA to the neighbor
	int16_t tx_er_border_idx;
	dbm_t tx_I;
	dbm_t tx_prev_I;
	dbm_t tx_delta_I_d;
	dbm_t tx_mean_delta_I_u;
#endif

	int16_t rx_interference_threshold;	
	uint8_t rx_version;
	/* boundary of the current exclusion region for the link to this neighbor (inbound), 
	 * i.e., outmost node index within the ER in SM
	 * ER is the set of neighbors from [0 .. ex_region_border_idx] in signalMap, not linkERTable
	 * EMPTY_ER_IDX (-1) means empty ER
	 */
	// when I receive DATA from the neighbor
	int16_t rx_er_border_idx;
	
	// min variance controller related info
	// \delta I (unknown error) = \delta I (measured/actual) - \delta I_d (desired)
	// capital I means in capsulation
	// mean noise+interference for a link during interval (t, t+1] so far
	dbm_t rx_I;
	// # of samples in interval (t, t+1] so far
	//int16_t tx_i_cnt;
	//int16_t rx_i_cnt;
	// I(t - 1): mean interference+noise for a link during interval (t - 1, t]
	dbm_t rx_prev_I;
	//int16_t tx_prev_i;
	//int16_t rx_prev_i;
	// \Delta I_d(t): previous desired NI change; scaled
	dbm_t rx_delta_I_d;
	// \bar(\Delta I_u(t)) mean delta unknown NI change; scaled
	dbm_t rx_mean_delta_I_u;
	
	/*
	 * d_0 related; only neighbors w/ an active link w/ me
	 * in case of bidirectional link, there are two entries w/ identical nb (different is_sender though). d_0 is store at the 1st entry
	 */
	//// inbound d_0
	// category 0
	uint32_t d0_self_mean;
	uint32_t d0_self_var;
	// category 1
	uint32_t d0_other_mean;
	uint32_t d0_other_var;
	//// outbound d_0
	uint32_t d0_self_qtl;
	uint32_t d0_other_qtl;
} local_link_er_table_entry_t;

#endif
