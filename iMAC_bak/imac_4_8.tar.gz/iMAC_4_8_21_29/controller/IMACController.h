/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 04/05/2012 08:56:00 PM 
 */

#ifndef IMAC_CONTROLLER_H
#define IMAC_CONTROLLER_H

enum {
	REFERENCE_PDR = 90,
};

#endif
