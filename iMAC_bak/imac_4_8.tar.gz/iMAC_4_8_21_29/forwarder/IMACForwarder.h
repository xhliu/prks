/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 04/05/2012 08:56:00 PM 
 */
 
#ifndef IMAC_FORWARDER_H
#define IMAC_FORWARDER_H

enum {
	TYPE_RTS 	= 1,
	TYPE_CTS 	= 2,
	TYPE_DATA 	= 3,
	
	CTS_TIMEOUT = 20,
	// data longer than CTS, generally speaking
	DATA_TIMEOUT = 25,
	
	// max retries for RTS
	RTS_MAX_RETRIES = 8,
	
	// radio tx data rate: 250 kpbs
	DATA_RATE = 250,
	// max physical frame length in bit
	MAX_PHY_LEN = 127 * 8,
};

// state machine of iMAC
enum {
	S_IDLE,
	S_SENDING_RTS,
	S_SENDING_CTS,
	S_SENDING_DATA,
	S_EXPECTING_CTS,
	S_EXPECTING_DATA,
};

// iMAC header: RTS/CTS only contains header, while data packet contains additional upper layer payload
typedef nx_struct {
	// iMAC pkts: RTS/CTS/data
	nx_uint8_t type;
	
	// receiver; only for RTS/CTS, not for data
	nx_am_addr_t dst;
	
	// P(S, R) / K : decides exclusion region
	nx_uint16_t interference_threshold;
	
	// network allocation vector for virtual carries sensing
	nx_uint16_t nav;
} imac_header_t;

#endif
