/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 04/05/2012 08:56:00 PM 
 */
#ifndef IMAC_CONTROLLER_H
#define IMAC_CONTROLLER_H

#include "IMAC.h"
#include "SignalMap.h"

enum {
	// scaled by 100
	DELTA_Y = 0,
	// 0.15: scaled by 100
	E0 = 15,
	
	// empty ER
	EMPTY_ER_IDX = -1,
};

// ER and PDR of the link btw. me and nb
typedef nx_struct {
	// ER
	// am I the sender?
	nx_bool is_sender;
	nx_am_addr_t nb;
	//nx_int16_t tx_interference_threshold;
	//nx_int16_t rx_interference_threshold;
	// is_sender decides whether tx/rx_interference_threshold
	nx_int16_t interference_threshold;
	
	// pdr
	nx_uint8_t inquality;
	nx_uint8_t inquality_version;
} link_er_pdr_t;

typedef nx_struct {
	// ER of link from/to a neighbor to/from me
	link_er_pdr_t link_er_pdr[LINK_ER_TABLE_SIZE];
} imac_control_header_t;

// link ER table entry
// store as a seperate table from signal map if memory is ever a concern since only neighbors talking to me need to be maintained, whose # is much less than SM_SIZE
// TODO: further reduce since a link is seldomly bidirectional, store seperately if this ever occurs, differentiated by is_sender
typedef struct {
	am_addr_t nb;

	bool valid;
	bool is_sender;
	// index within active links; used to compute priority
	uint8_t link_idx;

	int16_t tx_interference_threshold;
	int16_t rx_interference_threshold;	
	/* boundary of the current exclusion region for the link to this neighbor (inbound), 
	 * i.e., outmost node index within the ER in SM
	 * ER is the set of neighbors from [0 .. ex_region_border_idx] in signalMap, not linkERTable
	 * EMPTY_ER_IDX (-1) means empty ER
	 */
	// when I transmit DATA to the neighbor
	int16_t tx_er_border_idx;
	// when I receive DATA from the neighbor
	int16_t rx_er_border_idx;
	
	// min variance controller related info
	// \delta I (unknown error) = \delta I (measured/actual) - \delta I_d (desired)
	// capital I means in capsulation
	// mean noise+interference for a link during interval (t, t+1] so far
	dbm_t tx_I;
	dbm_t rx_I;
	// # of samples in interval (t, t+1] so far
	//int16_t tx_i_cnt;
	//int16_t rx_i_cnt;
	// I(t - 1): mean interference+noise for a link during interval (t - 1, t]
	dbm_t tx_prev_I;
	dbm_t rx_prev_I;
	//int16_t tx_prev_i;
	//int16_t rx_prev_i;
	// \Delta I_d(t): previous desired NI change; scaled
	dbm_t tx_delta_I_d;
	dbm_t rx_delta_I_d;
	// \bar(\Delta I_u(t)) mean delta unknown NI change; scaled
	dbm_t tx_mean_delta_I_u;
	dbm_t rx_mean_delta_I_u;
} link_er_table_entry_t;

typedef struct {
	am_addr_t nb;
	int16_t inbound_gain;
	int16_t outbound_gain;
} signal_map_entry_t;

// neighbor's signal map, from/to whom there is a link
typedef struct {
	am_addr_t nb;
	bool valid;
	signal_map_entry_t signal_map[SM_SIZE];
} nb_signal_map_entry_t;

// link table <link, ER>
typedef struct {
	am_addr_t sender;
	am_addr_t receiver;
	bool valid;
	// index within active links; used to compute priority
	uint8_t link_idx;
	// i-th bit of bitmap: this link contends w/ my i-th incident link?
	// TODO: # of incident link cannot exceed 8
	uint8_t bitmap;
	int16_t tx_interference_threshold;
	int16_t rx_interference_threshold;
} nb_link_er_table_entry_t;

#endif
