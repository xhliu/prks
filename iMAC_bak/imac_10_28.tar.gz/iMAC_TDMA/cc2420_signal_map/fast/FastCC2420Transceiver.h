#ifndef FAST_CC2420_TRANSCEIVER_H
#define FAST_CC2420_TRANSCEIVER_H

// to indicate padded or not
typedef nx_struct {
	nx_bool is_padded;
} fast_header_t;

// additional software CRC
typedef nx_uint16_t fast_footer_t;

#endif
