/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 06/27/2012 
 */
 
#ifndef IMAC_FORWARDER_H
#define IMAC_FORWARDER_H

enum {
//#warning long slot for debug
	// duration of a slot in jiffies:
	SLOT_LEN = 512,
	SLOT_LEN_SHIFT = 9,	// 2 ^ 9 = 512
	SLOT_HEX_MODULAR = 0x000001FF, // x % SLOT_LEN == x & SLOT_HEX_MODULAR

#warning based on diff btw. max DATA and max CONTROL delay
	// actual backoff window is BACKOFF_WINDOW + processing jitter from of send, including TXFIFO loading
	// probability of collision = 1%
	BACKOFF_WINDOW = 20,
	// tx duration
	TX_DURATION = 150,
	// only takes 9-10 ticks, be conservative
	CHANNEL_SWITCH_DELAY = 20,
	
	// tx ftsp beacon instead of ctrl pkt 1 out of CTRL_SLOT_FTSP_CHANCE when ctrl channel available
	INIT_CTRL_SLOT_FTSP_CHANCE = 2,
	CTRL_SLOT_FTSP_CHANCE = 2,
	// 1 out of 22,000; 22.2 s drifts 1 ms; be conservative and compensate drift every 2 s;
	// not exactly 65536 to avoid perfect alignment and the resulting 0 firing alarm
//	SYNC_PERIOD = 65535UL,
};

// TODO: redundant header lest sth needs to be piggybacked later
typedef nx_struct {
	nx_uint8_t seq;
} imac_header_t;


#endif
