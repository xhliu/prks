/*
 * Copyright (c) 2007, Vanderbilt University
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE VANDERBILT UNIVERSITY BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE VANDERBILT
 * UNIVERSITY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE VANDERBILT UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE VANDERBILT UNIVERSITY HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * Author: Miklos Maroti
 */

#ifndef __TIMESYNCMESSAGE_H__
#define __TIMESYNCMESSAGE_H__

#ifndef AM_TIMESYNCMSG
#define AM_TIMESYNCMSG 0x3D
#endif

#ifndef TIMESYNC_FIX
// this value is sent in the air
typedef nx_uint32_t timesync_radio_t;

typedef struct timesync_footer_t
{
	nx_am_id_t type;
  	timesync_radio_t timestamp;
} timesync_footer_t;

#else

typedef nx_struct {
	nx_uint32_t timestamp;
	// XL: denote whether writing to the payload after packet starts tx is successful or not; after timestamp so it gets transmitted later
	nx_uint8_t timestamp_overriden;
} timesync_radio_t;

enum {
	TIMESTAMP_NOT_OVERRIDEN = 0,
	TIMESTAMP_OVERRIDEN = 255,
};


typedef struct timesync_footer_t
{
#warning add seq# for debug
	nx_uint16_t seqno;
	nx_am_id_t type;
  	timesync_radio_t timesync;
} timesync_footer_t;

#endif

#endif//__TIMESYNCMESSAGE_H__
