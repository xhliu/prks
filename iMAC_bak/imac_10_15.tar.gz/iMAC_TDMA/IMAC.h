#ifndef IMAC_H
#define IMAC_H

enum {
	AM_IMAC_LE = 6,
	AM_IMAC_SM = 7,
	
	// EWMA, w/ a denominator of 10
	ALPHA = 9,
	SCALE_L_SHIFT_BIT = 7,
	
	// PDR requirement; differentiate data/ack reliability for now
	REFERENCE_DATA_PDR = 75,
	REFERENCE_ACK_PDR = 80,

	// corresponds to power level 3
	CC2420_DEF_RFPOWER_DBM = -25,
	CC2420_DEF_RFPOWER_DBM_SCALED = CC2420_DEF_RFPOWER_DBM << SCALE_L_SHIFT_BIT,
	// power level
	CONTROL_POWER_LEVEL = 31,
	
//#warning non default signal map size
	// size is int16_t to accommodate network consisting of more than 256 nodes
	SM_SIZE = 64,	//128,	// accommodate some illegitimate nodes of corrupted node id
	SM_SIZE_MODULAR = 0x3F,	//0x7F,	// x % SM_SIZE == x & SM_SIZE_MODULAR

	// max # of active links in the ntw
	MAX_ACTIVE_LINK_SIZE = 100,
	// max # of links a node can be incident w/
	MAX_INCIDENT_LINK_SIZE = 5,
	NB_SIGNAL_MAP_SIZE = MAX_INCIDENT_LINK_SIZE,
	LOCAL_LINK_ER_TABLE_SIZE = MAX_INCIDENT_LINK_SIZE,
	NEIGHBOR_TABLE_SIZE = MAX_INCIDENT_LINK_SIZE,
	LINK_ER_TABLE_SIZE = MAX_ACTIVE_LINK_SIZE,
	
	INVALID_ADDR = 0xFFFF,
//#warning fake control channel
	// control channel; see Guoliang RTSS09 Section 3B
	CC2420_CONTROL_CHANNEL = 19,
	
	// period to send signal map beacons at the beginning
	// 5 s = 32 * 1024 * 5 jiffies
#warning sm beacon period shorten to 100 ms
	SM_BEACON_PERIOD_JIFFY = 3200UL,	//163840UL,
	
};

#endif
