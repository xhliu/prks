/*
 * @ author: Xiaohui Liu (whulxh@gmail.com)
 * 
 * @ updated: 04/05/2012 08:56:00 PM 
 */

#ifndef IMAC_CONTROLLER_H
#define IMAC_CONTROLLER_H

enum {
	// scaled by 100
	DELTA_Y = 0,
	// 0.15: scaled by 100
	E0 = 15,
};
#endif
